<?php

return [
    'url' => 'http://localhost:8000',
    'asset_url' => null,
];
