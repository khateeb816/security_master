// Test file to verify web server access
console.log('Test script loaded successfully');
