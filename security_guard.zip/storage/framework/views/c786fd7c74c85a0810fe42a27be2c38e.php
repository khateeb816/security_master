<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(url('js/users.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('users', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bilawal\CascadeProjects\remote_project\resources\views/users_fixed.blade.php ENDPATH**/ ?>