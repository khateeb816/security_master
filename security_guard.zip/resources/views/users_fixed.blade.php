@extends('users')

@push('scripts')
<script src="{{ url('js/users.js') }}"></script>
@endpush
